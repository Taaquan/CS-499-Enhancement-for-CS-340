"""
ENHANCED CRUD MODULE
Adds full CRUD support plus filtering, sorting, projection, and aggregation.
"""

from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelterCRUD:
    """Reusable CRUD class for the AAC animals collection."""

    def __init__(
        self,
        username: str,
        password: str,
        host: str = "localhost",
        port: int = 27017,
        database_name: str = "aac",
        collection_name: str = "animals",
    ):
        self.username = username
        self.password = password
        self.host = host
        self.port = port
        self.database_name = database_name
        self.collection_name = collection_name

        try:
            uri = f"mongodb://{self.username}:{self.password}@{self.host}:{self.port}/aac?authSource=admin"
            self.client = MongoClient(uri)
            self.database = self.client[self.database_name]
            self.collection = self.database[self.collection_name]
            self.client.admin.command("ping")
        except PyMongoError as e:
            print(f"[ERROR] MongoDB connection/auth failed: {e}")
            self.client = None
            self.database = None
            self.collection = None

    def create(self, data: dict) -> bool:
        if self.collection is None:
            return False
        if not isinstance(data, dict) or len(data) == 0:
            return False
        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as e:
            print(f"[ERROR] Insert failed: {e}")
            return False

    def read(self, query: dict = None, projection: dict = None, sort: list = None, limit: int = 0) -> list:
        if self.collection is None:
            return []
        if query is None:
            query = {}
        if not isinstance(query, dict):
            return []
        try:
            cursor = self.collection.find(query, projection)
            if sort:
                cursor = cursor.sort(sort)
            if isinstance(limit, int) and limit > 0:
                cursor = cursor.limit(limit)
            return list(cursor)
        except PyMongoError as e:
            print(f"[ERROR] Read failed: {e}")
            return []

    def update(self, query: dict, new_values: dict) -> int:
        if self.collection is None or not isinstance(query, dict) or not isinstance(new_values, dict):
            return 0
        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except PyMongoError as e:
            print(f"[ERROR] Update failed: {e}")
            return 0

    def delete(self, query: dict) -> int:
        if self.collection is None or not isinstance(query, dict):
            return 0
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as e:
            print(f"[ERROR] Delete failed: {e}")
            return 0

    def aggregate(self, pipeline: list) -> list:
        if self.collection is None or not isinstance(pipeline, list):
            return []
        try:
            return list(self.collection.aggregate(pipeline))
        except PyMongoError as e:
            print(f"[ERROR] Aggregation failed: {e}")
            return []