"""
CRUD_Python_Module.py

Reusable CRUD class for MongoDB using PyMongo.
Module Four: Create (insert) and Read (find) functionality.

Database: aac
Collection: animals
User: aacuser
"""

from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelterCRUD:
    """Provides create and read operations for the AAC animals collection."""

    def __init__(
        self,
        username: str,
        password: str,
        host: str = "localhost",
        port: int = 27017,
        database_name: str = "aac",
        collection_name: str = "animals",
    ):
        """
        Initialize MongoDB connection with authentication.

        Args:
            username: MongoDB username (aacuser)
            password: MongoDB password
            host: MongoDB host
            port: MongoDB port
            database_name: Target database name ("aac")
            collection_name: Target collection name ("animals")
        """
        self.username = username
        self.password = password
        self.host = host
        self.port = port
        self.database_name = database_name
        self.collection_name = collection_name

        try:
            # authSource=aac because user was created with readWrite role on aac DB
            uri = f"mongodb://{self.username}:{self.password}@{self.host}:{self.port}/aac?authSource=admin"
            self.client = MongoClient(uri)
            self.database = self.client[self.database_name]
            self.collection = self.database[self.collection_name]

            # Quick connection check (throws if auth/connection fails)
            self.client.admin.command("ping")

        except PyMongoError as e:
            print(f"[ERROR] MongoDB connection/auth failed: {e}")
            self.client = None
            self.database = None
            self.collection = None

    def create(self, data: dict) -> bool:
        """
        Insert a single document into the collection.

        Args:
            data: dict of key/value pairs (MongoDB document)

        Returns:
            True if insert succeeded, else False
        """
        if self.collection is None:
            return False

        if not isinstance(data, dict) or len(data) == 0:
            return False

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as e:
            print(f"[ERROR] Insert failed: {e}")
            return False

    def read(self, query: dict) -> list:
        """
        Query documents from the collection using find() (NOT find_one()).

        Args:
            query: dict lookup pair(s) for MongoDB find()

        Returns:
            List of matching documents if successful, else empty list
        """
        if self.collection is None:
            return []

        if query is None:
            query = {}

        if not isinstance(query, dict):
            return []

        try:
            cursor = self.collection.find(query)
            results = list(cursor)  # Convert cursor to list for return
            return results
        except PyMongoError as e:
            print(f"[ERROR] Read failed: {e}")
            return []
